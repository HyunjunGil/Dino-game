class ScoreInfo {
  constructor (score) {
    this.score = score;
    this.time = new Date();
  }

}

const character = document.getElementById('character');
const block = document.getElementById('block');
const start = document.getElementById('startButton');
var counter = 0;
var onGame = false;
var rankers = new Map();
rankers.set(1, undefined);
rankers.set(2, undefined);
rankers.set(3, undefined);
rankers.set(4, undefined);
rankers.set(5, undefined);



function jump () {
  if (character.classList == 'animate' || !onGame ) return;
  character.classList.add('animate');
  setTimeout(function() {
    character.classList.remove('animate');
  }, 500);
}

function updateHighscore(score) {
  let result = new ScoreInfo(score);
  console.log('asdf', result.score, result.time);
    let i = 5;
    while (i > 0) {
      console.log('hi');
      if (rankers.get(i) === undefined || rankers.get(i).score <= result.score) {
        i--;
        console.log('hello');
      } else break;
    }
    i++;
    let j = 4;
    while (j >= i) {
      rankers.set(j+1, rankers.get(j));
      j--;
    }
    rankers.set(i, result);
    console.log('aaaaaa', rankers);
    for(let i = 1; i < 6; i++) {
      if (rankers.get(i) === undefined) {
        console.log('unexpected break');
        break;
      }
      var rowEl = document.getElementById('row' + i);
      console.log('bbbb', rowEl);
      document.getElementById('row' + i).innerHTML =
        `<td>${i}</td><td>${rankers.get(i).score}</td><td>${rankers.get(i).time}</td>`
    }
}


function startGame () {
  if (onGame) return;
  onGame = true;
  block.style.animation = 'block 1s infinite linear';
  const checkDead = setInterval(() => {
    const characterTop = parseInt(window.getComputedStyle(character).getPropertyValue("top"));
    const blockLeft = parseInt(window.getComputedStyle(block).getPropertyValue("left"));
    if (characterTop >= 130 && blockLeft > -20 && blockLeft <= 20) {
      block.style.animation = 'none';
      score = Math.floor(counter/100);
      alert('Game Over. Score: ' + score);
      updateHighscore(score);
      onGame = false;
      counter = 0;
      document.getElementById('scoreSpan').innerHTML = 0;
      clearInterval(checkDead);
    } else {
      counter++;
      document.getElementById('scoreSpan').innerHTML = Math.floor(counter/100);
    }
  }, 10);
}

document.addEventListener('keydown', jump);
start.addEventListener('click', startGame);





